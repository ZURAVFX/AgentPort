Web2AE v1.0.0 After Effects Companion

1. Close After Effects.
2. Run Install Web2AE.bat.
3. Restart After Effects.
4. Open Window > Extensions > Web2AE.

Created by Elliot Mckenzie / zura. MIT licensed.
